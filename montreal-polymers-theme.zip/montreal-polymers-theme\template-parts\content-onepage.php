<?php
/**
 * Template part for displaying the full Industrial One-Page layout
 * 100% matched to yellow.html design
 */
?>

<!-- ========================================================================= -->
<!-- 3. HERO BANNER (Industrial Deep Slate with 3D Golden WebGL Canvas) -->
<!-- ========================================================================= -->
<section id="home" class="relative bg-slate-900 text-white pt-16 pb-28 lg:pt-24 lg:pb-36 overflow-hidden">
    
    <!-- 3D Interactive WebGL Canvas -->
    <div id="hero-3d-canvas"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-20">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <!-- Left Content -->
            <div class="lg:col-span-7 space-y-6">
                
                <!-- Top Pill Badge -->
                <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-800/90 border border-slate-700 text-xs font-mono font-semibold text-gold-400">
                    <span class="w-2 h-2 rounded-full bg-gold-500 animate-pulse"></span>
                    <span>Zero Chemical Solvents • 100% Cold Mechanical Recovery</span>
                </div>

                <!-- Main H1 Headline -->
                <h1 class="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight font-display leading-[1.12]">
                    Saving Earth from Chemicals. <br>
                    <span class="text-gold-500">Zero Plastic Waste</span> to Landfills.
                </h1>

                <!-- Supporting Text -->
                <p class="text-base sm:text-lg text-slate-300 leading-relaxed font-light max-w-2xl">
                    Montreal Polymers replaces toxic chemical washing machines and hazardous incinerators with <strong>pure cold mechanical granulation</strong> — converting industrial PVC off-cuts and factory scrap into certified circular raw materials.
                </p>

                <!-- Dual Action CTAs -->
                <div class="flex flex-wrap items-center gap-4 pt-2">
                    <a href="#contact" class="px-8 py-4 rounded-xl font-bold text-sm uppercase tracking-wider text-slate-900 bg-gold-500 hover:bg-gold-400 transition-all shadow-gold-glow flex items-center gap-3">
                        <i data-lucide="truck" class="w-4 h-4"></i>
                        <span>Schedule Scrap Pickup</span>
                    </a>
                    <a href="#calculator" class="px-8 py-4 rounded-xl font-bold text-sm uppercase tracking-wider text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-all flex items-center gap-2">
                        <i data-lucide="calculator" class="w-4 h-4 text-gold-500"></i>
                        <span>Landfill ROI Calculator</span>
                    </a>
                </div>

                <!-- Micro Trust Indicators -->
                <div class="pt-6 border-t border-slate-800 flex flex-wrap items-center gap-6 text-xs text-slate-400 font-medium">
                    <div class="flex items-center gap-2">
                        <i data-lucide="check-circle-2" class="w-4 h-4 text-gold-500"></i>
                        <span>ISO & Recyc-Québec Aligned</span>
                    </div>
                    <div class="flex items-center gap-2">
                        <i data-lucide="check-circle-2" class="w-4 h-4 text-gold-500"></i>
                        <span>0L Hazardous Wastewater</span>
                    </div>
                    <div class="flex items-center gap-2">
                        <i data-lucide="check-circle-2" class="w-4 h-4 text-gold-500"></i>
                        <span>COA Lab Certificate with Every Lot</span>
                    </div>
                </div>

            </div>

            <!-- Right Specimen Card for Mobile & Live Availability -->
            <div class="lg:col-span-5 relative z-20 flex justify-end">
                <div class="w-full max-w-md bg-slate-800/80 backdrop-blur-md rounded-2xl p-6 border border-slate-700 shadow-2xl space-y-4">
                    <div class="flex items-center justify-between pb-3 border-b border-slate-700">
                        <div class="flex items-center gap-2">
                            <span class="w-2.5 h-2.5 rounded-full bg-gold-500"></span>
                            <span class="text-xs font-mono font-bold uppercase text-white tracking-wider">Trading Desk Availability</span>
                        </div>
                        <span class="text-[10px] font-mono text-gold-400 bg-gold-950/80 px-2 py-0.5 rounded border border-gold-800">LIVE FEED</span>
                    </div>
                    <div class="space-y-3 text-xs">
                        <div class="p-3 rounded-xl bg-slate-900/80 border border-slate-700/60 flex justify-between items-center">
                            <div>
                                <div class="font-bold text-white">Rigid PVC Regrind (White Profile)</div>
                                <div class="text-[11px] text-slate-400">Post-industrial window scrap • Bulk bags</div>
                            </div>
                            <span class="font-mono font-bold text-gold-400">44,000 lbs</span>
                        </div>
                        <div class="p-3 rounded-xl bg-slate-900/80 border border-slate-700/60 flex justify-between items-center">
                            <div>
                                <div class="font-bold text-white">HDPE Blow Molding Bales</div>
                                <div class="text-[11px] text-slate-400">Uncontaminated factory trimmings</div>
                            </div>
                            <span class="font-mono font-bold text-gold-400">88,000 lbs</span>
                        </div>
                        <div class="p-3 rounded-xl bg-slate-900/80 border border-slate-700/60 flex justify-between items-center">
                            <div>
                                <div class="font-bold text-white">PP Extrusion Grade Lumps</div>
                                <div class="text-[11px] text-slate-400">High MFI purge scrap • Laval dock</div>
                            </div>
                            <span class="font-mono font-bold text-gold-400">22,000 lbs</span>
                        </div>
                    </div>
                    <a href="#products" class="block text-center py-2.5 rounded-xl bg-gold-500 hover:bg-gold-400 text-slate-900 font-bold text-xs uppercase tracking-wider transition-colors shadow-sm">
                        Inspect Complete Specifications
                    </a>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- ========================================================================= -->
<!-- 4. FLOATING 4-STAT INDUSTRIAL METRICS BANNER -->
<!-- ========================================================================= -->
<div class="relative z-30 -mt-14 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <?php echo do_shortcode( '[montreal_stat_banner]' ); ?>
</div>

<!-- ========================================================================= -->
<!-- 5. SPLIT SECTION 1: THE CHEMICAL-FREE PHILOSOPHY (One side Image, other side Text) -->
<!-- ========================================================================= -->
<section class="py-24 bg-white overflow-hidden">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            
            <!-- Left Side: Real Industrial Machinery Imagery -->
            <div class="lg:col-span-6 relative reveal-on-scroll">
                <div class="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-200">
                    <img src="https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1000&q=80" alt="Industrial Cold Mechanical Granulation" class="w-full h-[480px] object-cover hover:scale-105 transition-transform duration-700">
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent"></div>
                    
                    <!-- Floating Spec Badge on Image -->
                    <div class="absolute bottom-6 left-6 right-6 p-4 rounded-2xl bg-white/95 backdrop-blur-md border border-slate-200 shadow-xl flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-xl bg-gold-500/20 text-gold-700 flex items-center justify-center font-bold">
                                <i data-lucide="cpu" class="w-5 h-5 text-gold-600"></i>
                            </div>
                            <div>
                                <div class="text-xs font-bold text-slate-900">Cold Mechanical Granulation</div>
                                <div class="text-[11px] text-slate-500">Zero Chemical Solvents • Preserved Molecular Weight</div>
                            </div>
                        </div>
                        <span class="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">0L Effluent</span>
                    </div>
                </div>

                <!-- Decorative Background Element -->
                <div class="absolute -top-6 -left-6 w-32 h-32 bg-gold-500/10 rounded-full blur-2xl -z-10"></div>
            </div>

            <!-- Right Side: Text & Editorial Case -->
            <div class="lg:col-span-6 space-y-6 reveal-on-scroll delay-100">
                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold-100 text-gold-800 text-xs font-mono font-semibold">
                    <i data-lucide="shield-alert" class="w-3.5 h-3.5"></i>
                    <span>OUR CORE ENVIRONMENTAL DIFFERENCE</span>
                </div>

                <h2 class="text-3xl sm:text-4xl font-extrabold text-slate-900 font-display tracking-tight leading-tight">
                    Why We Never Use Chemical Machines or Acid Washes.
                </h2>

                <p class="text-slate-600 leading-relaxed text-base font-light">
                    Many recycling companies rely on aggressive chemical baths, chlorinated solvents, and high-heat decomposition that degrade polymer chains and discharge toxic wastewater into Canadian waterways.
                </p>

                <p class="text-slate-600 leading-relaxed text-base font-light">
                    Montreal Polymers pioneered a <strong>100% cold mechanical circular process</strong>. We use heavy rotary granulators, high-gauss neodymium magnetic separators, and air-density gravity tables. The result is pure, re-usable polymer regrind that saves thousands of tons from landfills without creating a single drop of hazardous chemical byproduct.
                </p>

                <!-- Feature Breakdown Grid -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <div class="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                        <div class="flex items-center gap-2 text-slate-900 font-bold text-sm">
                            <i data-lucide="check" class="w-4 h-4 text-gold-600"></i>
                            <span>Zero Water Runoff</span>
                        </div>
                        <p class="text-xs text-slate-500">Clean, dry physical separation prevents soil and municipal water contamination.</p>
                    </div>
                    <div class="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                        <div class="flex items-center gap-2 text-slate-900 font-bold text-sm">
                            <i data-lucide="check" class="w-4 h-4 text-gold-600"></i>
                            <span>Preserved Intrinsic Viscosity</span>
                        </div>
                        <p class="text-xs text-slate-500">Cold processing preserves the virgin mechanical strength of PVC & HDPE polymers.</p>
                    </div>
                </div>

                <div class="pt-2">
                    <a href="#services" class="inline-flex items-center gap-2 text-sm font-bold text-slate-900 hover:text-gold-600 transition-colors">
                        <span>Explore Our Processing Capabilities</span>
                        <i data-lucide="arrow-right" class="w-4 h-4 text-gold-500"></i>
                    </a>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- ========================================================================= -->
<!-- 6. CORE SERVICES GRID (Wastex & Garbox Industrial Format) -->
<!-- ========================================================================= -->
<section id="services" class="py-24 bg-slate-50 border-y border-slate-200">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        <!-- Section Header -->
        <div class="max-w-3xl mx-auto text-center space-y-4 reveal-on-scroll">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold-100 text-gold-800 text-xs font-mono font-semibold">
                <span>SOLUTIONS FOR BUYERS & SELLERS</span>
            </div>
            <h2 class="text-3xl sm:text-4xl font-extrabold text-slate-900 font-display tracking-tight">
                End-to-End Industrial Polymer Recovery
            </h2>
            <p class="text-slate-600 text-base font-light">
                From factory dock drop trailers to certified extrusion-grade regrind, we bridge the gap between scrap producers and high-precision manufacturers.
            </p>
        </div>

        <!-- 6 Services Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            
            <!-- Service 1: Scrap Purchasing -->
            <div class="wp-card bg-white rounded-2xl p-8 border border-slate-200 shadow-soft space-y-4 relative overflow-hidden group reveal-on-scroll delay-100">
                <div class="w-12 h-12 rounded-xl bg-gold-500/10 text-gold-600 flex items-center justify-center font-bold group-hover:bg-gold-500 group-hover:text-slate-900 transition-colors">
                    <i data-lucide="scale" class="w-6 h-6"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-900">Post-Industrial Scrap Purchasing</h3>
                <p class="text-sm text-slate-600 leading-relaxed font-light">
                    We purchase clean bales, purged lumps, start-up scrap, and production off-cuts from plastics converters with certified scale receipts and rapid payout.
                </p>
                <ul class="text-xs text-slate-500 space-y-1.5 pt-2 border-t border-slate-100">
                    <li class="flex items-center gap-2"><i data-lucide="check" class="w-3.5 h-3.5 text-gold-600"></i> Drop trailer service in QC & ON</li>
                    <li class="flex items-center gap-2"><i data-lucide="check" class="w-3.5 h-3.5 text-gold-600"></i> Full truckloads (FTL) & LTL</li>
                </ul>
            </div>

            <!-- Service 2: Cold Granulation -->
            <div class="wp-card bg-white rounded-2xl p-8 border border-slate-200 shadow-soft space-y-4 relative overflow-hidden group reveal-on-scroll delay-200">
                <div class="w-12 h-12 rounded-xl bg-gold-500/10 text-gold-600 flex items-center justify-center font-bold group-hover:bg-gold-500 group-hover:text-slate-900 transition-colors">
                    <i data-lucide="scissors" class="w-6 h-6"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-900">Toll Shredding & Granulation</h3>
                <p class="text-sm text-slate-600 leading-relaxed font-light">
                    Contract toll processing for compounders who need their internal scrap converted into uniform regrind flakes without cross-contamination.
                </p>
                <ul class="text-xs text-slate-500 space-y-1.5 pt-2 border-t border-slate-100">
                    <li class="flex items-center gap-2"><i data-lucide="check" class="w-3.5 h-3.5 text-gold-600"></i> 3/8" to 5/16" screen classification</li>
                    <li class="flex items-center gap-2"><i data-lucide="check" class="w-3.5 h-3.5 text-gold-600"></i> Complete batch decontamination</li>
                </ul>
            </div>

            <!-- Service 3: PVC Specialty Stream -->
            <div class="wp-card bg-white rounded-2xl p-8 border-2 border-gold-500/80 shadow-soft space-y-4 relative overflow-hidden group reveal-on-scroll delay-300">
                <div class="absolute top-3 right-3 text-[10px] font-mono font-bold uppercase bg-gold-500 text-slate-900 px-2 py-0.5 rounded">
                    Specialty Flagship
                </div>
                <div class="w-12 h-12 rounded-xl bg-gold-500 text-slate-900 flex items-center justify-center font-bold">
                    <i data-lucide="layers" class="w-6 h-6"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-900">Rigid PVC Stream Dedicated Line</h3>
                <p class="text-sm text-slate-600 leading-relaxed font-light">
                    Quebec's most dedicated recovery line for rigid PVC window profiles, siding off-cuts, and conduit scrap, de-dusted with fines removed.
                </p>
                <ul class="text-xs text-slate-500 space-y-1.5 pt-2 border-t border-slate-100">
                    <li class="flex items-center gap-2"><i data-lucide="check" class="w-3.5 h-3.5 text-gold-600"></i> White, off-white, and dark regrind</li>
                    <li class="flex items-center gap-2"><i data-lucide="check" class="w-3.5 h-3.5 text-gold-600"></i> Moisture &lt; 0.01% guarantee</li>
                </ul>
            </div>

            <!-- Service 4: Zero Landfill Audit -->
            <div class="wp-card bg-white rounded-2xl p-8 border border-slate-200 shadow-soft space-y-4 relative overflow-hidden group reveal-on-scroll delay-100">
                <div class="w-12 h-12 rounded-xl bg-gold-500/10 text-gold-600 flex items-center justify-center font-bold group-hover:bg-gold-500 group-hover:text-slate-900 transition-colors">
                    <i data-lucide="leaf" class="w-6 h-6"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-900">Zero-Landfill Plant Programs</h3>
                <p class="text-sm text-slate-600 leading-relaxed font-light">
                    We audit your manufacturing facility floor, set up color-coded scrap totes, and train your staff to maximize scrap value and eliminate tipping fees.
                </p>
                <ul class="text-xs text-slate-500 space-y-1.5 pt-2 border-t border-slate-100">
                    <li class="flex items-center gap-2"><i data-lucide="check" class="w-3.5 h-3.5 text-gold-600"></i> ESG & Recyc-Québec documentation</li>
                    <li class="flex items-center gap-2"><i data-lucide="check" class="w-3.5 h-3.5 text-gold-600"></i> Guaranteed 100% diversion certificate</li>
                </ul>
            </div>

            <!-- Service 5: Compounding Raw Materials -->
            <div class="wp-card bg-white rounded-2xl p-8 border border-slate-200 shadow-soft space-y-4 relative overflow-hidden group reveal-on-scroll delay-200">
                <div class="w-12 h-12 rounded-xl bg-gold-500/10 text-gold-600 flex items-center justify-center font-bold group-hover:bg-gold-500 group-hover:text-slate-900 transition-colors">
                    <i data-lucide="box" class="w-6 h-6"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-900">Custom Sourced Regrind Batches</h3>
                <p class="text-sm text-slate-600 leading-relaxed font-light">
                    We supply extruders, injection molders, and rotomolders with steady monthly railcars or truckloads of certified specification regrind.
                </p>
                <ul class="text-xs text-slate-500 space-y-1.5 pt-2 border-t border-slate-100">
                    <li class="flex items-center gap-2"><i data-lucide="check" class="w-3.5 h-3.5 text-gold-600"></i> Continuous contract allocations</li>
                    <li class="flex items-center gap-2"><i data-lucide="check" class="w-3.5 h-3.5 text-gold-600"></i> Super sacks, gaylords, or bulk</li>
                </ul>
            </div>

            <!-- Service 6: Cross-Border Logistics -->
            <div class="wp-card bg-white rounded-2xl p-8 border border-slate-200 shadow-soft space-y-4 relative overflow-hidden group reveal-on-scroll delay-300">
                <div class="w-12 h-12 rounded-xl bg-gold-500/10 text-gold-600 flex items-center justify-center font-bold group-hover:bg-gold-500 group-hover:text-slate-900 transition-colors">
                    <i data-lucide="globe-2" class="w-6 h-6"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-900">Cross-Border Trading Desk</h3>
                <p class="text-sm text-slate-600 leading-relaxed font-light">
                    Seamless logistics between Canada and US border states with complete customs paperwork, phytosanitary pallet certification, and ocean container drayage.
                </p>
                <ul class="text-xs text-slate-500 space-y-1.5 pt-2 border-t border-slate-100">
                    <li class="flex items-center gap-2"><i data-lucide="check" class="w-3.5 h-3.5 text-gold-600"></i> USMCA / CUSMA certified documentation</li>
                    <li class="flex items-center gap-2"><i data-lucide="check" class="w-3.5 h-3.5 text-gold-600"></i> Rapid customs brokerage clearance</li>
                </ul>
            </div>

        </div>
    </div>
</section>

<!-- ========================================================================= -->
<!-- 7. SPLIT SECTION 2: FACTORY SCRAP LOGISTICS (One side Text, other side Image) -->
<!-- ========================================================================= -->
<section class="py-24 bg-white overflow-hidden">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            
            <!-- Left Side: Text for Factory Owners -->
            <div class="lg:col-span-6 space-y-6 reveal-on-scroll">
                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold-100 text-gold-800 text-xs font-mono font-semibold">
                    <i data-lucide="truck" class="w-3.5 h-3.5"></i>
                    <span>FOR FACTORIES & CONVERTERS</span>
                </div>

                <h2 class="text-3xl sm:text-4xl font-extrabold text-slate-900 font-display tracking-tight leading-tight">
                    Turn Post-Industrial Scrap Into Working Capital Within 48 Hours.
                </h2>

                <p class="text-slate-600 leading-relaxed text-base font-light">
                    Factory space is too valuable to be cluttered with rejected parts, start-up lumps, and skeletal punch scrap. We provide turnkey scrap removal for manufacturing plants across Quebec and Ontario.
                </p>

                <div class="space-y-3 pt-2">
                    <div class="flex items-start gap-3">
                        <div class="w-6 h-6 rounded-full bg-gold-500/20 text-gold-700 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                            <i data-lucide="check" class="w-4 h-4 text-gold-600"></i>
                        </div>
                        <div>
                            <h4 class="text-sm font-bold text-slate-900">Dedicated On-Site Drop Trailers</h4>
                            <p class="text-xs text-slate-500">We place a 53-ft dry van at your dock. You load your scrap as produced; when full, we swap it within 48 hours.</p>
                        </div>
                    </div>

                    <div class="flex items-start gap-3">
                        <div class="w-6 h-6 rounded-full bg-gold-500/20 text-gold-700 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                            <i data-lucide="check" class="w-4 h-4 text-gold-600"></i>
                        </div>
                        <div>
                            <h4 class="text-sm font-bold text-slate-900">Certified Weight Receipts</h4>
                            <p class="text-xs text-slate-500">Every trailer is scaled in and out on calibrated Government of Canada certified scales with photographic verification.</p>
                        </div>
                    </div>

                    <div class="flex items-start gap-3">
                        <div class="w-6 h-6 rounded-full bg-gold-500/20 text-gold-700 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                            <i data-lucide="check" class="w-4 h-4 text-gold-600"></i>
                        </div>
                        <div>
                            <h4 class="text-sm font-bold text-slate-900">Reliable Terms & Prompt Settlements</h4>
                            <p class="text-xs text-slate-500">Clear indexed pricing per pound and fast Net-15 or Net-30 settlements so your cash flow is protected.</p>
                        </div>
                    </div>
                </div>

                <div class="pt-2">
                    <a href="#contact" class="px-6 py-3.5 rounded-xl font-bold text-xs uppercase tracking-wider text-slate-900 bg-gold-500 hover:bg-gold-400 transition-all shadow-gold-glow inline-flex items-center gap-2">
                        <span>Sell Factory Scrap Now</span>
                        <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
                    </a>
                </div>
            </div>

            <!-- Right Side: Real Logistics Warehouse Image -->
            <div class="lg:col-span-6 relative reveal-on-scroll delay-100">
                <div class="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-200">
                    <img src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1000&q=80" alt="Montreal Polymers Logistics and Receiving Docks" class="w-full h-[480px] object-cover hover:scale-105 transition-transform duration-700">
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent"></div>
                    
                    <!-- Floating Logistics Badge on Image -->
                    <div class="absolute bottom-6 left-6 right-6 p-4 rounded-2xl bg-white/95 backdrop-blur-md border border-slate-200 shadow-xl flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-xl bg-gold-500/20 text-gold-700 flex items-center justify-center font-bold">
                                <i data-lucide="warehouse" class="w-5 h-5 text-gold-600"></i>
                            </div>
                            <div>
                                <div class="text-xs font-bold text-slate-900">Laval Receiving Hub</div>
                                <div class="text-[11px] text-slate-500">Fast Dock Swaps Across Montreal & Toronto Corridors</div>
                            </div>
                        </div>
                        <span class="text-xs font-mono font-bold text-slate-900 bg-gold-400 px-2.5 py-1 rounded-lg">48h Swap</span>
                    </div>
                </div>

                <!-- Decorative Background Element -->
                <div class="absolute -bottom-6 -right-6 w-32 h-32 bg-gold-500/10 rounded-full blur-2xl -z-10"></div>
            </div>

        </div>
    </div>
</section>

<!-- ========================================================================= -->
<!-- 8. RIGID PVC STREAM SPECIALIZATION -->
<!-- ========================================================================= -->
<section id="pvc" class="py-24 bg-slate-900 text-white relative overflow-hidden">
    
    <!-- Subtle Glow Effect -->
    <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-gold-500/5 rounded-full blur-3xl pointer-events-none"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-16">
        
        <div class="max-w-3xl mx-auto text-center space-y-4 reveal-on-scroll">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800 text-gold-400 text-xs font-mono font-semibold border border-slate-700">
                <span class="w-2 h-2 rounded-full bg-gold-500"></span>
                <span>OUR FLAGSHIP MATERIAL EXCELLENCE</span>
            </div>
            <h2 class="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight">
                Quebec's Most Dedicated Rigid PVC Recovery Stream
            </h2>
            <p class="text-slate-300 text-base font-light">
                PVC (Polyvinyl Chloride) requires strict segregation from other polymers. Even 0.1% PET or Polyolefin contamination destroys an extrusion run. Our specialized PVC line ensures pure, laboratory-verified flakes.
            </p>
        </div>

        <!-- PVC Comparison & Specifications Table -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            <!-- Card 1: Window & Door Profile -->
            <div class="bg-slate-800/90 rounded-2xl p-6 border border-slate-700 shadow-xl space-y-4 reveal-on-scroll delay-100">
                <div class="flex justify-between items-start">
                    <span class="text-xs font-mono font-bold uppercase text-gold-400 bg-gold-950/80 px-2 py-0.5 rounded border border-gold-800">Grade A-1</span>
                    <i data-lucide="check-circle" class="w-5 h-5 text-gold-500"></i>
                </div>
                <h3 class="text-xl font-bold text-white">Window & Door Regrind</h3>
                <p class="text-xs text-slate-400 leading-relaxed">
                    Pure white and off-white window profile scrap without gaskets, steel reinforcement, or protective tape.
                </p>
                <div class="space-y-2 pt-3 border-t border-slate-700 text-xs font-mono">
                    <div class="flex justify-between text-slate-300">
                        <span>MFI / Melt Flow:</span>
                        <span class="font-bold text-white">0.8 – 1.2 g/10min</span>
                    </div>
                    <div class="flex justify-between text-slate-300">
                        <span>Specific Gravity:</span>
                        <span class="font-bold text-white">1.42 – 1.45</span>
                    </div>
                    <div class="flex justify-between text-slate-300">
                        <span>Fines Content (&lt;20 mesh):</span>
                        <span class="font-bold text-gold-400">&lt; 0.5% (De-dusted)</span>
                    </div>
                </div>
                <a href="#contact" class="block text-center py-2.5 rounded-xl bg-slate-700 hover:bg-gold-500 hover:text-slate-900 text-white font-bold text-xs uppercase tracking-wider transition-colors">
                    Request Spec Sheet
                </a>
            </div>

            <!-- Card 2: Pipe & Conduit Regrind -->
            <div class="bg-slate-800/90 rounded-2xl p-6 border-2 border-gold-500 shadow-xl space-y-4 relative reveal-on-scroll delay-200">
                <div class="absolute -top-3 right-6 bg-gold-500 text-slate-900 font-bold text-[10px] font-mono px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                    Highest Volume
                </div>
                <div class="flex justify-between items-start">
                    <span class="text-xs font-mono font-bold uppercase text-gold-400 bg-gold-950/80 px-2 py-0.5 rounded border border-gold-800">Grade B-1</span>
                    <i data-lucide="layers" class="w-5 h-5 text-gold-500"></i>
                </div>
                <h3 class="text-xl font-bold text-white">Pipe & Conduit Scrap</h3>
                <p class="text-xs text-slate-400 leading-relaxed">
                    Electrical conduit, municipal drainage pipe cut-offs, and sewer pipe regrind, sorted by gray and white colors.
                </p>
                <div class="space-y-2 pt-3 border-t border-slate-700 text-xs font-mono">
                    <div class="flex justify-between text-slate-300">
                        <span>Color Classification:</span>
                        <span class="font-bold text-white">Dark Gray / White</span>
                    </div>
                    <div class="flex justify-between text-slate-300">
                        <span>Screen Size:</span>
                        <span class="font-bold text-white">3/8" (9.5mm)</span>
                    </div>
                    <div class="flex justify-between text-slate-300">
                        <span>Moisture Guarantee:</span>
                        <span class="font-bold text-gold-400">&lt; 0.01%</span>
                    </div>
                </div>
                <a href="#contact" class="block text-center py-2.5 rounded-xl bg-gold-500 hover:bg-gold-400 text-slate-900 font-bold text-xs uppercase tracking-wider transition-colors shadow-gold-glow">
                    Request Material RFQ
                </a>
            </div>

            <!-- Card 3: Siding & Foam Profiles -->
            <div class="bg-slate-800/90 rounded-2xl p-6 border border-slate-700 shadow-xl space-y-4 reveal-on-scroll delay-300">
                <div class="flex justify-between items-start">
                    <span class="text-xs font-mono font-bold uppercase text-gold-400 bg-gold-950/80 px-2 py-0.5 rounded border border-gold-800">Grade C-2</span>
                    <i data-lucide="package" class="w-5 h-5 text-gold-500"></i>
                </div>
                <h3 class="text-xl font-bold text-white">Siding & Foam Board Regrind</h3>
                <p class="text-xs text-slate-400 leading-relaxed">
                    Cellular and rigid PVC building siding scrap, clean post-industrial material in gaylords or super sacks.
                </p>
                <div class="space-y-2 pt-3 border-t border-slate-700 text-xs font-mono">
                    <div class="flex justify-between text-slate-300">
                        <span>Bulk Density:</span>
                        <span class="font-bold text-white">0.55 – 0.65 g/cm³</span>
                    </div>
                    <div class="flex justify-between text-slate-300">
                        <span>Packaging:</span>
                        <span class="font-bold text-white">Gaylord Box / Liner</span>
                    </div>
                    <div class="flex justify-between text-slate-300">
                        <span>Monthly Capacity:</span>
                        <span class="font-bold text-gold-400">120,000 lbs</span>
                    </div>
                </div>
                <a href="#contact" class="block text-center py-2.5 rounded-xl bg-slate-700 hover:bg-gold-500 hover:text-slate-900 text-white font-bold text-xs uppercase tracking-wider transition-colors">
                    Request Spec Sheet
                </a>
            </div>

        </div>

    </div>
</section>

<!-- ========================================================================= -->
<!-- 9. SPLIT SECTION 3: TECHNICAL SPECIFICATIONS & TESTING (One side Image, other side Text) -->
<!-- ========================================================================= -->
<section id="products" class="py-24 bg-white overflow-hidden">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            
            <!-- Left Side: Granules & Flakes Photo -->
            <div class="lg:col-span-6 relative reveal-on-scroll">
                <div class="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-200">
                    <img src="https://images.unsplash.com/photo-1610891015188-5369212db097?auto=format&fit=crop&w=1000&q=80" alt="Recycled Polymer Granules and Flakes" class="w-full h-[480px] object-cover hover:scale-105 transition-transform duration-700">
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent"></div>
                    
                    <!-- Floating QA Badge on Image -->
                    <div class="absolute bottom-6 left-6 right-6 p-4 rounded-2xl bg-white/95 backdrop-blur-md border border-slate-200 shadow-xl flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-xl bg-gold-500/20 text-gold-700 flex items-center justify-center font-bold">
                                <i data-lucide="check-check" class="w-5 h-5 text-gold-600"></i>
                            </div>
                            <div>
                                <div class="text-xs font-bold text-slate-900">Lab Batch Certification</div>
                                <div class="text-[11px] text-slate-500">Every Gaylord & Super Sack Tested for Zero Contamination</div>
                            </div>
                        </div>
                        <span class="text-xs font-mono font-bold text-slate-900 bg-gold-400 px-2.5 py-1 rounded-lg">99.9% Pure</span>
                    </div>
                </div>

                <!-- Decorative Background Element -->
                <div class="absolute -top-6 -left-6 w-32 h-32 bg-gold-500/10 rounded-full blur-2xl -z-10"></div>
            </div>

            <!-- Right Side: Quality Assurance Narrative -->
            <div class="lg:col-span-6 space-y-6 reveal-on-scroll delay-100">
                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold-100 text-gold-800 text-xs font-mono font-semibold">
                    <i data-lucide="award" class="w-3.5 h-3.5"></i>
                    <span>QUALITY ASSURANCE FOR COMPOUNDERS</span>
                </div>

                <h2 class="text-3xl sm:text-4xl font-extrabold text-slate-900 font-display tracking-tight leading-tight">
                    Laboratory Tested. Barcoded Gaylords. Guaranteed Delivery.
                </h2>

                <p class="text-slate-600 leading-relaxed text-base font-light">
                    Procurement managers cannot afford machine downtime caused by unvetted scrap traders. At Montreal Polymers, every shipment is supported by an official Certificate of Analysis (COA) specifying melt flow index, contamination thresholds, and bulk density.
                </p>

                <div class="grid grid-cols-2 gap-4 pt-2">
                    <div class="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                        <div class="text-lg font-extrabold text-slate-900">&lt; 0.01%</div>
                        <div class="text-xs font-semibold text-slate-500 uppercase">Max Moisture Threshold</div>
                    </div>
                    <div class="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                        <div class="text-lg font-extrabold text-slate-900">0 ppm</div>
                        <div class="text-xs font-semibold text-slate-500 uppercase">Ferrous Metal Contamination</div>
                    </div>
                    <div class="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                        <div class="text-lg font-extrabold text-slate-900">100% Traceable</div>
                        <div class="text-xs font-semibold text-slate-500 uppercase">Single-Source Factory Scrap</div>
                    </div>
                    <div class="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                        <div class="text-lg font-extrabold text-slate-900">CUSMA Ready</div>
                        <div class="text-xs font-semibold text-slate-500 uppercase">Cross-Border Custom Papers</div>
                    </div>
                </div>

                <div class="pt-2">
                    <a href="#contact" class="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl font-bold text-xs uppercase tracking-wider text-slate-900 bg-gold-500 hover:bg-gold-400 transition-all shadow-gold-glow">
                        <span>Request Sample Gaylord / Spec Sheet</span>
                        <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
                    </a>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- ========================================================================= -->
<!-- 10. 4-STEP COLD MECHANICAL PROCESS (Garbox Step Numbering) -->
<!-- ========================================================================= -->
<section class="py-24 bg-slate-50 border-t border-slate-200">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        <div class="max-w-3xl mx-auto text-center space-y-4 reveal-on-scroll">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold-100 text-gold-800 text-xs font-mono font-semibold">
                <span>STEP-BY-STEP WORKFLOW</span>
            </div>
            <h2 class="text-3xl sm:text-4xl font-extrabold text-slate-900 font-display tracking-tight">
                How Montreal Polymers Processes Industrial Scrap
            </h2>
            <p class="text-slate-600 text-base font-light">
                A disciplined 4-stage mechanical protocol that safeguards purity, preserves polymer chains, and eliminates landfill waste.
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            
            <!-- Step 1 -->
            <div class="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-soft space-y-4 relative reveal-on-scroll delay-100">
                <div class="w-10 h-10 rounded-full bg-gold-500 text-slate-900 font-extrabold font-mono flex items-center justify-center text-sm shadow-md">
                    01
                </div>
                <h3 class="text-lg font-bold text-slate-900">Dock Receiving & Sort</h3>
                <p class="text-xs text-slate-600 leading-relaxed font-light">
                    Scrap arrives via drop trailer or flatbed. Every lot is weighed on certified scales and inspected for polymer grade, color segregation, and purity.
                </p>
                <div class="text-[11px] font-mono text-gold-700 bg-gold-50 px-2 py-1 rounded">
                    Certified Scale Ticket Issued
                </div>
            </div>

            <!-- Step 2 -->
            <div class="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-soft space-y-4 relative reveal-on-scroll delay-200">
                <div class="w-10 h-10 rounded-full bg-gold-500 text-slate-900 font-extrabold font-mono flex items-center justify-center text-sm shadow-md">
                    02
                </div>
                <h3 class="text-lg font-bold text-slate-900">Magnetic De-Ironing</h3>
                <p class="text-xs text-slate-600 leading-relaxed font-light">
                    Heavy cross-belt neodymium magnets extract screws, steel fasteners, and metallic inserts from window frames or assembly trimmings.
                </p>
                <div class="text-[11px] font-mono text-gold-700 bg-gold-50 px-2 py-1 rounded">
                    12,000 Gauss Neodymium
                </div>
            </div>

            <!-- Step 3 -->
            <div class="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-soft space-y-4 relative reveal-on-scroll delay-300">
                <div class="w-10 h-10 rounded-full bg-gold-500 text-slate-900 font-extrabold font-mono flex items-center justify-center text-sm shadow-md">
                    03
                </div>
                <h3 class="text-lg font-bold text-slate-900">Cold Mechanical Granulation</h3>
                <p class="text-xs text-slate-600 leading-relaxed font-light">
                    Heavy-duty water-cooled rotor knives reduce rigid pieces into uniform 3/8" regrind flakes without thermal burn or chemical solvents.
                </p>
                <div class="text-[11px] font-mono text-gold-700 bg-gold-50 px-2 py-1 rounded">
                    0% Chemical Solvents Used
                </div>
            </div>

            <!-- Step 4 -->
            <div class="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-soft space-y-4 relative reveal-on-scroll delay-400">
                <div class="w-10 h-10 rounded-full bg-gold-500 text-slate-900 font-extrabold font-mono flex items-center justify-center text-sm shadow-md">
                    04
                </div>
                <h3 class="text-lg font-bold text-slate-900">Aspiration, QA & Dispatch</h3>
                <p class="text-xs text-slate-600 leading-relaxed font-light">
                    Air classifiers remove micro-fines and dust. Flakes are packed into lined gaylord boxes or bulk bags, barcoded, and lab-certified for dispatch.
                </p>
                <div class="text-[11px] font-mono text-gold-700 bg-gold-50 px-2 py-1 rounded">
                    COA Issued per 44,000 lbs FTL
                </div>
            </div>

        </div>
    </div>
</section>

<!-- ========================================================================= -->
<!-- 11. INTERACTIVE LANDFILL & REVENUE CALCULATOR -->
<!-- ========================================================================= -->
<section id="calculator" class="py-24 bg-white border-t border-slate-200">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 reveal-on-scroll">
        
        <div class="text-center space-y-4">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold-100 text-gold-800 text-xs font-mono font-semibold">
                <i data-lucide="calculator" class="w-3.5 h-3.5"></i>
                <span>INTERACTIVE ESG & REVENUE ESTIMATOR</span>
            </div>
            <h2 class="text-3xl sm:text-4xl font-extrabold text-slate-900 font-display tracking-tight">
                Calculate Landfill Diversion & Monthly Scrap Value
            </h2>
            <p class="text-slate-600 text-base font-light max-w-2xl mx-auto">
                Adjust your monthly manufacturing scrap volume below to calculate total cubic meters spared from Canadian landfills and estimated scrap payout.
            </p>
        </div>

        <?php echo do_shortcode( '[montreal_landfill_calculator]' ); ?>

    </div>
</section>

<!-- ========================================================================= -->
<!-- 12. DUAL CONVERSION FUNNEL (Request RFQ vs Sell Scrap) -->
<!-- ========================================================================= -->
<section id="contact" class="py-24 bg-slate-50 border-t border-slate-200">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        <div class="text-center space-y-4 reveal-on-scroll">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold-100 text-gold-800 text-xs font-mono font-semibold">
                <i data-lucide="send" class="w-3.5 h-3.5"></i>
                <span>FAST RESPONSE GUARANTEED</span>
            </div>
            <h2 class="text-3xl sm:text-4xl font-extrabold text-slate-900 font-display tracking-tight">
                Direct Contact With Our Montreal Trading Desk
            </h2>
            <p class="text-slate-600 text-base font-light max-w-2xl mx-auto">
                Select your operational objective below. Whether buying certified regrind or dispatching industrial scrap, our trading desk responds within 2 business hours.
            </p>
        </div>

        <!-- Form Card with Tab Switcher -->
        <?php echo do_shortcode( '[montreal_contact_form]' ); ?>

    </div>
</section>
